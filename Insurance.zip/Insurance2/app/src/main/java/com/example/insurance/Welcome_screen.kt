package com.example.insurance

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class Welcome_screen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome_screen)
        val imageView1 = findViewById<CardView>(R.id.start);
        imageView1.setOnClickListener {
            val intent = Intent(this@Welcome_screen, MainActivity::class.java)
            startActivity(intent);
        }
    }
}